"""Simple Windows Code Auto-Typer

Run this single file with Python. It installs missing dependencies automatically.
Copy code, click the target editor, press F8 to type, and press Esc to stop.
"""
import importlib.util
import subprocess
import sys
import time
import threading
import ctypes
from ctypes import wintypes

# Easy settings to change
CHAR_DELAY = 0.015  # Seconds between characters
START_DELAY = 3     # Seconds to focus the target editor after pressing F8

# Install the two required packages only if they're missing.
def ensure_package(import_name, package_name):
    if importlib.util.find_spec(import_name) is None:
        print(f"Installing {package_name}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--user", package_name])

try:
    ensure_package("pyperclip", "pyperclip")
    ensure_package("pynput", "pynput")
    import pyperclip
    from pynput import keyboard
    from pynput.keyboard import Key
except Exception as exc:
    input(f"Could not set up requirements: {exc}\nPress Enter to close...")
    raise SystemExit(1)

# Windows Unicode keyboard input support.
ULONG_PTR = wintypes.WPARAM
class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]
class INPUT_UNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT)]
class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("union", INPUT_UNION)]

INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
user32 = ctypes.WinDLL("user32", use_last_error=True)
user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
user32.SendInput.restype = wintypes.UINT
controller = keyboard.Controller()
busy = threading.Event()
stop_requested = threading.Event()

def send_unicode_char(char):
    for offset in range(0, len(char.encode("utf-16-le")), 2):
        encoded = char.encode("utf-16-le")
        unit = int.from_bytes(encoded[offset:offset + 2], "little")
        for flags in (KEYEVENTF_UNICODE, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP):
            event = INPUT(type=INPUT_KEYBOARD, union=INPUT_UNION(ki=KEYBDINPUT(
                wVk=0, wScan=unit, dwFlags=flags, time=0, dwExtraInfo=0)))
            if user32.SendInput(1, ctypes.byref(event), ctypes.sizeof(INPUT)) != 1:
                raise ctypes.WinError(ctypes.get_last_error())

def type_clipboard():
    if busy.is_set():
        return
    try:
        text = pyperclip.paste()
        if not text:
            print("Clipboard is empty. Copy your code first.")
            return
        busy.set()
        stop_requested.clear()
        print(f"Typing {len(text)} characters in {START_DELAY} seconds. Click the target editor now.")
        print("Press Esc to stop. Text already typed will remain.")
        for _ in range(START_DELAY * 10):
            if stop_requested.is_set():
                print("Cancelled.")
                return
            time.sleep(0.1)
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        for char in text:
            if stop_requested.is_set():
                print("Stopped. Text already entered remains in the editor.")
                break
            if char == "\n":
                controller.press(Key.enter); controller.release(Key.enter)
            elif char == "\t":
                controller.press(Key.tab); controller.release(Key.tab)
            else:
                send_unicode_char(char)
            if CHAR_DELAY > 0:
                time.sleep(CHAR_DELAY)
        else:
            print("Finished typing.")
    except Exception as exc:
        print(f"Typing error: {exc}")
    finally:
        busy.clear()

def on_press(key):
    if key == Key.f8 and not busy.is_set():
        threading.Thread(target=type_clipboard, daemon=True).start()
    elif key == Key.esc:
        stop_requested.set()

def main():
    if sys.platform != "win32":
        input("This program works on Windows only. Press Enter to close...")
        return
    print("WINDOWS CODE AUTO-TYPER")
    print("1. Copy code with Ctrl+C.")
    print("2. Click the target editor where the code should go.")
    print("3. Press F8; you have a short countdown to focus the editor.")
    print("4. Press Esc to stop. Text already typed is not undone.")
    print("Leave this window open. Close it to exit.\n")
    try:
        with keyboard.Listener(on_press=on_press) as listener:
            listener.join()
    except Exception as exc:
        input(f"Could not start keyboard listener: {exc}\nPress Enter to close...")

if __name__ == "__main__":
    main()
