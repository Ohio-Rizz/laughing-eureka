WINDOWS CODE AUTO-TYPER
=======================

FILES
-----
auto_typer.py                  The Python program.
Start Auto Typer.bat            Starts the program.
Edit Auto Typer in Notepad.bat  Opens the script in Notepad for editing.
Install Requirements.bat        Installs the required Python packages.
README.txt                      These instructions.

SETUP
-----
Your earlier log showed pyperclip and pynput installed successfully.
If you need to install them again, double-click Install Requirements.bat.

You can also open the ArcGIS Pro Python Command Prompt and run:
python -m pip install --user pyperclip pynput

EDIT THE SCRIPT IN NOTEPAD
--------------------------
Double-click "Edit Auto Typer in Notepad.bat".
Make your changes, then press Ctrl+S and close Notepad.
The editor opens auto_typer.py in this folder. Make sure you save as a
Python file named auto_typer.py, not auto_typer.py.txt.

If you are creating the file manually in Notepad:
1. Choose File > Save As.
2. Set "Save as type" to "All Files (*.*)".
3. Enter the filename: auto_typer.py
4. Choose UTF-8 encoding if the option is shown.
5. Save it in the same folder as the .bat launchers.

RUN
---
1. Double-click Start Auto Typer.bat.
2. Copy code with Ctrl+C.
3. Click the destination editor at the insertion point.
4. Press F8; the countdown gives you time to focus the editor.
5. Press Esc to stop. Text already entered is not undone.

IMPORTANT
---------
Do not enter Python statements directly into the Windows Command Prompt.
The commands "python -m pip ..." are Command Prompt commands; lines like
"import time" belong inside auto_typer.py.

Test a short snippet in Notepad before using a large code block. Some
applications may handle simulated keystrokes, tabs, symbols, or line breaks
differently. Use only where automated typing is permitted.
