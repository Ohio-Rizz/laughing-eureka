"""
Windows Code Auto-Typer
Copy code, focus the target editor, then press F8.
Press Esc to stop typing. Already-entered text is not undone.
"""

import ctypes
import threading
import time
from ctypes import wintypes

import pyperclip
from pynput import keyboard
from pynput.keyboard import Key

# Adjust these settings if needed.
CHAR_DELAY = 0.015       # Delay between characters, in seconds
START_DELAY = 3          # Time to focus the destination after pressing F8

# Windows SendInput definitions for Unicode keyboard events.
ULONG_PTR = wintypes.WPARAM

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]

class INPUT_UNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [
        ("type", wintypes.DWORD),
        ("union", INPUT_UNION),
    ]

INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004

user32 = ctypes.WinDLL("user32", use_last_error=True)
user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
user32.SendInput.restype = wintypes.UINT

controller = keyboard.Controller()
busy = threading.Event()
stop_requested = threading.Event()


def send_unicode_char(char):
    """Send a Unicode character using Windows Unicode keyboard events."""
    # Windows accepts UTF-16 code units. This also handles characters outside
    # the Basic Multilingual Plane by sending their surrogate pair.
    encoded = char.encode("utf-16-le")
    for offset in range(0, len(encoded), 2):
        unit = int.from_bytes(encoded[offset:offset + 2], "little")

        down = INPUT(
            type=INPUT_KEYBOARD,
            union=INPUT_UNION(ki=KEYBDINPUT(
                wVk=0, wScan=unit, dwFlags=KEYEVENTF_UNICODE,
                time=0, dwExtraInfo=0
            ))
        )
        up = INPUT(
            type=INPUT_KEYBOARD,
            union=INPUT_UNION(ki=KEYBDINPUT(
                wVk=0, wScan=unit,
                dwFlags=KEYEVENTF_UNICODE | KEYEVENTF_KEYUP,
                time=0, dwExtraInfo=0
            ))
        )

        if user32.SendInput(1, ctypes.byref(down), ctypes.sizeof(INPUT)) != 1:
            raise ctypes.WinError(ctypes.get_last_error())
        if user32.SendInput(1, ctypes.byref(up), ctypes.sizeof(INPUT)) != 1:
            raise ctypes.WinError(ctypes.get_last_error())


def type_clipboard():
    if busy.is_set():
        return

    try:
        text = pyperclip.paste()
    except Exception as exc:
        print(f"Could not read clipboard: {exc}")
        return

    if not text:
        print("Clipboard is empty. Copy your code first.")
        return

    busy.set()
    stop_requested.clear()
    try:
        print(f"Typing {len(text)} characters in {START_DELAY} seconds.")
        print("Focus the target editor now. Press Esc at any time to stop.")
        for _ in range(START_DELAY * 10):
            if stop_requested.is_set():
                print("Cancelled.")
                return
            time.sleep(0.1)

        # Normalize Windows, Unix, and old Mac line endings.
        text = text.replace("\r\n", "\n").replace("\r", "\n")

        for char in text:
            if stop_requested.is_set():
                print("Stopped. Text already entered remains in the editor.")
                break

            if char == "\n":
                controller.press(Key.enter)
                controller.release(Key.enter)
            elif char == "\t":
                controller.press(Key.tab)
                controller.release(Key.tab)
            else:
                send_unicode_char(char)

            if CHAR_DELAY > 0:
                time.sleep(CHAR_DELAY)
        else:
            print("Finished typing.")

    except Exception as exc:
        print(f"Typing error: {exc}")
    finally:
        busy.clear()


def on_press(key):
    if key == Key.f8:
        if not busy.is_set():
            threading.Thread(target=type_clipboard, daemon=True).start()
    elif key == Key.esc:
        stop_requested.set()


def main():
    print("Windows Code Auto-Typer is ready.")
    print("1. Copy your code with Ctrl+C.")
    print("2. Click the target editor where code should go.")
    print("3. Press F8. You have a 3-second focus countdown.")
    print("4. Press Esc to stop. This does not undo entered text.")
    print("Keep this window open while using the auto-typer.")
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()


if __name__ == "__main__":
    main()
