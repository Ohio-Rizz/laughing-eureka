@echo off
setlocal
set "ARCGIS_PY=C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe"
if exist "%ARCGIS_PY%" (
  "%ARCGIS_PY%" -m pip install --user pyperclip pynput
) else (
  python -m pip install pyperclip pynput
)
echo.
echo If installation reported an error, review it above.
pause
