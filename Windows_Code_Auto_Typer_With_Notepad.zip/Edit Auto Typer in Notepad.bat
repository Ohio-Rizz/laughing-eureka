@echo off
set "SCRIPT=%~dp0auto_typer.py"
if not exist "%SCRIPT%" (
  echo Could not find auto_typer.py in this folder.
  pause
  exit /b 1
)
notepad "%SCRIPT%"
