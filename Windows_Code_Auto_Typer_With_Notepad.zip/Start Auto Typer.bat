@echo off
setlocal
set "ARCGIS_PY=C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe"

if exist "%ARCGIS_PY%" (
    "%ARCGIS_PY%" -u "%~dp0auto_typer.py"
) else (
    python -u "%~dp0auto_typer.py"
)

echo.
echo Auto-typer closed. If an error appeared above, read it before closing.
pause
