"""
Windows Auto Typer — one-file version.
No pyperclip or pynput required. Uses built-in tkinter and Windows APIs.
Run with: py Windows_Auto_Typer.py
"""
import os
import sys
import time
import threading
import subprocess
import ctypes
import tkinter as tk
from tkinter import messagebox
from ctypes import wintypes

if sys.platform != "win32":
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror("Windows Auto Typer", "This program only works on Windows.")
    raise SystemExit(1)

# Settings
COUNTDOWN_SECONDS = 5
CHAR_DELAY = 0.008

user32 = ctypes.WinDLL("user32", use_last_error=True)
ULONG_PTR = ctypes.c_size_t

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]

class INPUT_UNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("union", INPUT_UNION)]

INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
VK_RETURN = 0x0D
VK_TAB = 0x09

user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
user32.SendInput.restype = wintypes.UINT

def send_key(vk):
    for flags in (0, KEYEVENTF_KEYUP):
        event = INPUT(type=INPUT_KEYBOARD, union=INPUT_UNION(
            ki=KEYBDINPUT(vk, 0, flags, 0, 0)))
        if user32.SendInput(1, ctypes.byref(event), ctypes.sizeof(INPUT)) != 1:
            raise ctypes.WinError(ctypes.get_last_error())

def send_unicode_char(char):
    # Send UTF-16 code units, including surrogate pairs for characters outside the BMP.
    raw = char.encode("utf-16-le", errors="surrogatepass")
    for offset in range(0, len(raw), 2):
        unit = int.from_bytes(raw[offset:offset + 2], "little")
        for flags in (KEYEVENTF_UNICODE, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP):
            event = INPUT(type=INPUT_KEYBOARD, union=INPUT_UNION(
                ki=KEYBDINPUT(0, unit, flags, 0, 0)))
            if user32.SendInput(1, ctypes.byref(event), ctypes.sizeof(INPUT)) != 1:
                raise ctypes.WinError(ctypes.get_last_error())

class AutoTyper:
    def __init__(self, root):
        self.root = root
        self.root.title("Windows Auto Typer")
        self.root.geometry("460x300")
        self.root.resizable(False, False)
        self.running = False
        self.cancel = threading.Event()

        tk.Label(root, text="Windows Auto Typer", font=("Segoe UI", 16, "bold")).pack(pady=(16, 5))
        tk.Label(root, text="A simple one-file tool — no extra Python packages needed.",
                 font=("Segoe UI", 9)).pack(pady=(0, 12))

        tk.Button(root, text="1. Open Notepad", width=28, height=2,
                  command=self.open_notepad).pack(pady=4)
        tk.Button(root, text="2. Type copied clipboard text", width=28, height=2,
                  command=self.start_typing).pack(pady=4)

        self.status = tk.StringVar(value="Copy your code, then click “Type copied clipboard text”.")
        tk.Label(root, textvariable=self.status, wraplength=410, justify="center",
                 fg="#245a8d").pack(pady=12)

        bottom = tk.Frame(root)
        bottom.pack(pady=2)
        tk.Button(bottom, text="Cancel typing", command=self.cancel_typing).pack(side="left", padx=5)
        tk.Button(bottom, text="Exit", command=root.destroy).pack(side="left", padx=5)

        root.bind("<Escape>", lambda _event: self.cancel_typing())

    def open_notepad(self):
        try:
            subprocess.Popen(["notepad.exe"])
            self.status.set("Notepad opened. Copy your code, then click the typing button.")
        except Exception as exc:
            messagebox.showerror("Could not open Notepad", str(exc))

    def start_typing(self):
        if self.running:
            return
        try:
            text = self.root.clipboard_get()
        except tk.TclError:
            messagebox.showwarning("Clipboard is empty", "Copy your code or text first, then try again.")
            return
        if not text:
            messagebox.showwarning("Clipboard is empty", "Copy your code or text first, then try again.")
            return
        self.running = True
        self.cancel.clear()
        threading.Thread(target=self.type_worker, args=(text,), daemon=True).start()

    def set_status(self, text):
        self.root.after(0, self.status.set, text)

    def type_worker(self, text):
        try:
            for remaining in range(COUNTDOWN_SECONDS, 0, -1):
                if self.cancel.is_set():
                    self.set_status("Cancelled.")
                    return
                self.set_status(f"Typing starts in {remaining}… Click Notepad and choose the insertion point now.")
                time.sleep(1)
            normalized = text.replace("\r\n", "\n").replace("\r", "\n")
            for index, char in enumerate(normalized):
                if self.cancel.is_set():
                    self.set_status("Stopped. Text already typed remains in Notepad.")
                    return
                if char == "\n":
                    send_key(VK_RETURN)
                elif char == "\t":
                    send_key(VK_TAB)
                else:
                    send_unicode_char(char)
                if CHAR_DELAY:
                    time.sleep(CHAR_DELAY)
            self.set_status("Finished typing.")
        except Exception as exc:
            self.set_status(f"Typing error: {exc}")
            error_text = str(exc)
            self.root.after(0, lambda msg=error_text: messagebox.showerror("Typing error", msg))
        finally:
            self.running = False

    def cancel_typing(self):
        if self.running:
            self.cancel.set()
            self.status.set("Cancelling…")

def main():
    root = tk.Tk()
    AutoTyper(root)
    root.mainloop()

if __name__ == "__main__":
    main()
